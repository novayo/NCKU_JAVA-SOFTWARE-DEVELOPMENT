package com.demo.utils;

public interface IOperation {
	
	abstract String perform(String num1, String num2);
	
}
