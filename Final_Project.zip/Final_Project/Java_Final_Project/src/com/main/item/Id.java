package com.main.item;

public enum Id {
	Player1, Player2, Stone, Floor1, Floor2;
}
